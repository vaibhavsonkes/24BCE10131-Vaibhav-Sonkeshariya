const express = require('express');
const router = express.Router();
const Ward = require('../models/Ward');

// Create
router.post('/', async (req, res) => {
  try {
    const ward = new Ward(req.body);
    await ward.save();
    res.status(201).json(ward);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get All
router.get('/', async (req, res) => {
  try {
    const wards = await Ward.find().populate('patients');
    res.json(wards);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get by ID
router.get('/:id', async (req, res) => {
  try {
    const ward = await Ward.findById(req.params.id).populate('patients');
    if (!ward) return res.status(404).json({ error: 'Ward not found' });
    res.json(ward);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update
router.put('/:id', async (req, res) => {
  try {
    const ward = await Ward.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(ward);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete
router.delete('/:id', async (req, res) => {
  try {
    await Ward.findByIdAndDelete(req.params.id);
    res.json({ message: 'Ward deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
