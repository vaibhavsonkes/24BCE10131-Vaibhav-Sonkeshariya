# Hospital Management System

A backend-only REST API project built using **Node.js (Express.js)** and **MongoDB**, designed to manage hospital data including Patients, Doctors, Appointments, and Wards.

This project has no frontend. All endpoints are tested using **Postman**.

---

## Tech Stack

- **Runtime:** Node.js
- **Framework:** Express.js
- **Database:** MongoDB (local or MongoDB Atlas)
- **ODM:** Mongoose
- **Testing Tool:** Postman

---

## Folder Structure

```
hospital-management/
├── models/
│   ├── Patient.js
│   ├── Doctor.js
│   ├── Appointment.js
│   └── Ward.js
├── routes/
│   ├── patients.js
│   ├── doctors.js
│   ├── appointments.js
│   └── wards.js
├── .env
├── app.js
└── package.json
```

---

## Entities

| Entity | Description | Fields |
|---|---|---|
| Patient | Stores patient details | name, age, gender, contact, ward_id |
| Doctor | Stores doctor details | name, specialization, contact, department |
| Appointment | Links a patient with a doctor | date, time, status, patient_id, doctor_id |
| Ward | Stores ward details | ward_name, type, capacity |

---

## Relationships

| Type | Entities | Description |
|---|---|---|
| One to One | Patient — Bed/Ward slot | One patient occupies one bed |
| One to Many | Doctor — Appointments | One doctor can have many appointments |
| Many to One | Patients — Ward | Many patients can belong to one ward |
| Many to Many | Doctors — Patients | A doctor treats many patients; a patient can see many doctors |

---

## Setup Instructions

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment variables
Create a `.env` file in the root folder (already included):
```
MONGO_URI=mongodb://localhost:27017/hospital_db
PORT=3000
```

> If using MongoDB Atlas instead of local MongoDB, replace `MONGO_URI` with your Atlas connection string.

### 3. Start MongoDB
If using local MongoDB, run in a separate terminal:
```bash
mongod
```

### 4. Run the project
```bash
npm run dev
```

You should see:
```
MongoDB Connected
Server running on port 3000
```

---

## API Endpoints

### Patients
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/patients | Add a new patient |
| GET | /api/patients | Get all patients |
| GET | /api/patients/:id | Get patient by ID |
| PUT | /api/patients/:id | Update patient details |
| DELETE | /api/patients/:id | Delete a patient |

### Doctors
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/doctors | Register a new doctor |
| GET | /api/doctors | Get all doctors |
| GET | /api/doctors/:id | Get doctor by ID |
| PUT | /api/doctors/:id | Update doctor details |
| DELETE | /api/doctors/:id | Delete a doctor |

### Appointments
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/appointments | Book a new appointment |
| GET | /api/appointments | Get all appointments |
| GET | /api/appointments/:id | Get appointment by ID |
| PUT | /api/appointments/:id | Reschedule or update appointment |
| DELETE | /api/appointments/:id | Cancel an appointment |

### Wards
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/wards | Add a new ward |
| GET | /api/wards | Get all wards |
| GET | /api/wards/:id | Get ward by ID |
| PUT | /api/wards/:id | Update ward details |
| DELETE | /api/wards/:id | Delete a ward |

---

## Testing Order (Important)

Since Patients reference Wards, and Appointments reference both Patients and Doctors, follow this order while testing in Postman:

1. Create **Wards** first → copy their `_id`
2. Create **Doctors** → copy their `_id`
3. Create **Patients** (using `ward_id` from step 1) → copy their `_id`
4. Create **Appointments** (using `patient_id` and `doctor_id` from steps 2 & 3)
5. Test GET, PUT, and DELETE on all four modules

---

## Sample Request Body

**Create Ward**
```json
{
  "ward_name": "General Ward",
  "type": "General",
  "capacity": 20
}
```

**Create Doctor**
```json
{
  "name": "Dr. Sharma",
  "specialization": "Cardiology",
  "contact": "9812345678",
  "department": "Heart"
}
```

**Create Patient**
```json
{
  "name": "Ramesh Kumar",
  "age": 35,
  "gender": "Male",
  "contact": "9876543210",
  "ward_id": "<ward _id here>"
}
```

**Create Appointment**
```json
{
  "date": "2026-06-20",
  "time": "10:30 AM",
  "status": "Scheduled",
  "patient_id": "<patient _id here>",
  "doctor_id": "<doctor _id here>"
}
```

---

## Viewing Data

Use **MongoDB Compass** to connect to `mongodb://localhost:27017` and view the `hospital_db` database in Table View for a clean tabular display of all collections.

---

## Author

Hospital Management System — Backend REST API Project (Node.js + Express.js + MongoDB)
