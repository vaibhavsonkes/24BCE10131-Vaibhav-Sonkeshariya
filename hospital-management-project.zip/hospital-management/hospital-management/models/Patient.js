const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  age: { type: Number, required: true },
  gender: { type: String, required: true },
  contact: { type: String, required: true },
  ward_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Ward' }
}, { timestamps: true });

module.exports = mongoose.model('Patient', patientSchema);
