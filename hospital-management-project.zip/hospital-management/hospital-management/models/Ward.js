const mongoose = require('mongoose');

const wardSchema = new mongoose.Schema({
  ward_name: { type: String, required: true },
  type: { type: String, required: true },
  capacity: { type: Number, required: true },
  patients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Patient' }]
}, { timestamps: true });

module.exports = mongoose.model('Ward', wardSchema);
